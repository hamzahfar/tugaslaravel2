<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php if($errors->any()): ?>
        <div style="color:red;">
            <?php echo e($errors->first()); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="/login">
        <?php echo csrf_field(); ?>
        <div>
            <label>Email</label><br>
            <input type="email" name="email" required>
        </div>
        <br>
        <div>
            <label>Password</label><br>
            <input type="password" name="password" required>
        </div>
        <br>
        <button type="submit">Login</button>
    </form>
</body>
</html>
<?php /**PATH D:\Project laravel\tugas2\resources\views/auth/login.blade.php ENDPATH**/ ?>